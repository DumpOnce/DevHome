create view vision as
select `bestdb`.`employees`.`id`          AS `id`,
       `bestdb`.`employees`.`lastname`    AS `lastname`,
       `bestdb`.`employees`.`firstname`   AS `firstname`,
       `bestdb`.`employees`.`phone`       AS `phone`,
       `bestdb`.`employees`.`dateofbirth` AS `dateofbirth`,
       `bestdb`.`employees`.`money`       AS `money`
from `bestdb`.`employees`
where (`bestdb`.`employees`.`lastname` = 'Petrov');

